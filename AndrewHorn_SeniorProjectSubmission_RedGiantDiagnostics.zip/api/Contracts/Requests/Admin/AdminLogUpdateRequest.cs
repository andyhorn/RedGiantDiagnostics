namespace API.Contracts.Requests.Admin
{
    public class AdminLogUpdateRequest : LogUpdateRequest
    {
        
    }
}