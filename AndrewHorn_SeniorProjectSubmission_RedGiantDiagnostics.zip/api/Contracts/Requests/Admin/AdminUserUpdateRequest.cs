namespace API.Contracts.Requests.Admin
{
    public class AdminUserUpdateRequest : UserUpdateRequest
    {
        
    }
}