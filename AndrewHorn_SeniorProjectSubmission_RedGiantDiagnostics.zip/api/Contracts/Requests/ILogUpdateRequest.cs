namespace API.Contracts.Requests
{
    public interface ILogUpdateRequest
    {
        
    }
}