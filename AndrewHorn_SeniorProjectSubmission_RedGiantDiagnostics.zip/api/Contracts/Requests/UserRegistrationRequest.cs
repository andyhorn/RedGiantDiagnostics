namespace API.Contracts.Requests
{
    // This class has been retired with V1 of the API
    public class UserRegistrationRequest
    {
        public string EmailAddress { get; set; }
        public string Password { get; set; }
    }
}