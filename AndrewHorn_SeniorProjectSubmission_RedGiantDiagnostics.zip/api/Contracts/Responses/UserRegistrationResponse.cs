namespace API.Contracts
{
    public class UserRegistrationResponse
    {
        public string UserId { get; set; }
        public string Token { get; set; }
    }
}