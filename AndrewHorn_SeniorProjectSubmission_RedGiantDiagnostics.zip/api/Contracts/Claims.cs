namespace API.Contracts
{
    public static class Claims
    {
        public const string UserId = "UserId";
        public const int ExpiresInDays = 14;
    }
}