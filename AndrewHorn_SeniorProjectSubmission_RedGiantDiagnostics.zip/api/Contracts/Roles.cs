namespace API.Contracts
{
    public static class Roles
    {
        public const string Admin = "Administrator";
        public const string User = "User";
    }
}