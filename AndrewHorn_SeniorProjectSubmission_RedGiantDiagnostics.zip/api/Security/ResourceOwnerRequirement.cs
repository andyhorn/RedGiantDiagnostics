using Microsoft.AspNetCore.Authorization;

namespace API.Security
{
    public class ResourceOwnerRequirement : IAuthorizationRequirement
    {
        
    }
}