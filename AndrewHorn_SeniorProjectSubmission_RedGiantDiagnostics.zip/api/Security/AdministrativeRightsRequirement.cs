using Microsoft.AspNetCore.Authorization;

namespace API.Security
{
    public class AdministrativeRightsRequirement : IAuthorizationRequirement
    {
        
    }
}