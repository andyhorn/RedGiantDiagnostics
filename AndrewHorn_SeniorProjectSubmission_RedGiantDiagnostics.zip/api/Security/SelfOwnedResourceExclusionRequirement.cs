﻿using Microsoft.AspNetCore.Authorization;

namespace API.Security
{
    public class SelfOwnedResourceExclusionRequirement : IAuthorizationRequirement
    {
        
    }
}