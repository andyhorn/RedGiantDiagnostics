using System;

namespace API.Exceptions
{
    public class ResourceConflictException : Exception
    {

    }
}