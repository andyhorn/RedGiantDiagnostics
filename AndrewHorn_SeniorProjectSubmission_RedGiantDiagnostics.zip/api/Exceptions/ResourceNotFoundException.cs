using System;

namespace API.Exceptions
{
    public class ResourceNotFoundException : Exception
    {
        
    }
}