namespace API.Models
{
    public interface IAnalysisResult
    {
        
    }
}